from django.core.management.base import BaseCommand
from AppleApp.models import Product

class Command(BaseCommand):
    help = 'Populates the database with initial products'

    def handle(self, *args, **kwargs):
        products = [
            {'name': 'iPhone 16 Pro', 'category': 'iPhone', 'price': 129900, 'image': 'https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-16-pro-finish-select-202409-6-1inch-deserttitanium?wid=2560&hei=1440&fmt=jpeg&qlt=80&.v=1724414331814'},
            # Add more products from user_main_page.html
        ]
        for product in products:
            Product.objects.get_or_create(
                name=product['name'],
                defaults={
                    'category': product['category'],
                    'price': product['price'],
                    'image': product['image'],
                    'description': f"{product['name']} description"
                }
            )
        self.stdout.write(self.style.SUCCESS('Successfully populated products'))