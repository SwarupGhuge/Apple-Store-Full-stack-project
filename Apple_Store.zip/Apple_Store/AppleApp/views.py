from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib import messages
from django.conf import settings
from .models import Product
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .forms import RegistrationForm, ProductForm
import logging
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import user_passes_test
import razorpay
from django.views.decorators.csrf import csrf_exempt
from razorpay.errors import SignatureVerificationError
# ✅ Setup logger
logger = logging.getLogger(__name__)

# ✅ Register View
def Register(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful! Please log in.")
            return redirect('Login')  # ✅ Redirect to login
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = RegistrationForm()
    return render(request, 'Registration.html', {'form': form})




def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_active:
            login(request, user)
            # Redirect superusers/staff to admin dashboard
            if user.is_superuser or user.is_staff:
                return redirect('admin_dashboard')
            else:
                return redirect('user_main_page')
        else:
            messages.error(request, 'Invalid username, password, or unverified account.')
    return render(request, 'Login.html')

# ✅ Logout
def logout_view(request):
    logger.info(f"Logging out user: {request.user.username if request.user.is_authenticated else 'Anonymous'}")
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('Frontpage')


@login_required
def user_main_page(request):
    products = Product.objects.all()
    return render(request, 'user_main_page.html', {'products': products})



# @login_required
# def admin_dashboard(request):
#     products = Product.objects.all().order_by('-id')  # latest first
#     return render(request, 'admin_dashboard.html', {'products': products})


@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def admin_dashboard(request):
    products = Product.objects.all().order_by('-id')  # Latest first
    return render(request, 'admin_dashboard.html', {'products': products})




def Frontpage(request):
    return render(request, 'Frontpage.html')

def MAC(request):
    return render(request, 'MAC.html')

def Privacy(request):
    return render(request, 'Privacy.html')

def Terms(request):
    return render(request, 'Terms.html')

def Contact(request):
    return render(request, 'Contact.html')

def iphoneclick(request):
    return render(request, 'Iphone_click.html')

def MAC_Click(request):
    return render(request, 'MAC_Click.html')

def ipad_click(request):
    return render(request, 'ipad_click.html')

def Watch_Click(request):
    return render(request, 'Watch_Click.html')

def support_click(request):
    return render(request, 'support_click.html')


# ✅ Admin Table Views
def table(request):
    return render(request, 'admintable.html')



@user_passes_test(lambda u: u.is_superuser)
def edit_product(request, id):
    product = get_object_or_404(Product, id=id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})

@login_required
def Update(request, id):
    product = get_object_or_404(Product, id=id)
    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
        else:
            print(form.errors)  # 🧪 Debug: Check for validation errors
    else:
        form = ProductForm(instance=product)
    return render(request, 'update_product.html', {'form': form})






@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def delete_product(request, id):
    product = get_object_or_404(Product, id=id)

    if request.method == 'POST':
        product.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect('admin_dashboard')

    return render(request, 'delete_product.html', {'product': product})


from .models import Product

def main_page(request):
    products = Product.objects.all()
    return render(request, 'main.html', {'products': products})

####################### add to cart #################################

from django.shortcuts import render, redirect, get_object_or_404
from .models import Product



def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session['cart'] = cart
    messages.success(request, "Product added to cart!")
    return redirect('user_main_page')  # Redirect to user main page

def view_cart(request):
    if request.method=="POST":
        return redirect('razorpayhome')
    cart = request.session.get('cart', {})
    products = []
    total = 0
    for product_id, quantity in cart.items():
        product = get_object_or_404(Product, id=product_id)
        product.quantity = quantity
        product.total_price = float(product.price) * quantity  # Convert Decimal to float for calculation
        total += product.total_price
        products.append(product)
        request.session["tamount"]=int(float(total)*100)
    return render(request, 'cart.html', {'products': products, 'total': total})

# views.py
from .models import Product

def user_home(request):
    products = Product.objects.all()
    return render(request, 'user_main_page.html', {'products': products})


####### New one ###########
@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Product added successfully!")
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form})


# Create your views here.

razorpay_client = razorpay.Client(auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))

def razorpayhome(request):
    
    razor_id=settings.RAZOR_KEY_ID
    razor_key=settings.RAZOR_KEY_SECRET 
    
    
    razorpay_order = razorpay_client.order.create({"amount":request.session.get("tamount"),"currency":"INR","payment_capture":"0"}) 
    print(razorpay_order)
    context = {
        'amount':razorpay_order["amount"],
        'orderid':razorpay_order["id"],
        'rid':settings.RAZOR_KEY_ID,
    }
    return render(request,'razorpayhome.html',context)

@csrf_exempt
def paymenthandler(request):
    if request.method=="POST":
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            print(payment_id)
            print(razorpay_order_id)
            print(signature)
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
            
            try: 
                razorpay_client.utility.verify_payment_signature(params_dict)
                # amt=12300
                razorpay_client.payment.capture(payment_id, request.session.get("tamount"))
                payment_details = razorpay_client.payment.fetch(payment_id)
                print(payment_details)
                return redirect('view_cart')
            

                
            except SignatureVerificationError as e:
                print(e)
                return render(request,'user_main_page.html')
            


