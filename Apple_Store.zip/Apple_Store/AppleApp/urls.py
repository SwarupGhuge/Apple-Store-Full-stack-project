from django.urls import path
from . import views


urlpatterns = [
    path('', views.Frontpage, name='Frontpage'),
    path('mac/', views.MAC, name='mac'),
    path('privacy/', views.Privacy, name='Privacy'),
    path('terms/', views.Terms, name='Terms'),
    path('contact/', views.Contact, name='Contact'),
    path('iphoneclick/', views.iphoneclick, name='iphone_click'),
    path('macclick/', views.MAC_Click, name='MAC_Click'),
    path('ipadclick/', views.ipad_click, name='ipad_click'),
    path('watchclick/', views.Watch_Click, name='Watch_click'),
    path('supportclick/', views.support_click, name='support_click'),
    path('register/', views.Register, name='Register'),
    path('login/', views.login_view, name='Login'),
    path('user_main_page/', views.user_main_page, name='user_main_page'),
    path('table/', views.table, name='table'),
    path('edit-product/<int:id>/', views.edit_product, name='edit_product'),
    path('delete-product/<int:id>/', views.delete_product, name='delete_product'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.user_main_page, name='user_main_page'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('edit/<int:id>/', views.Update, name='edit_product'),
    path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.view_cart, name='view_cart'),
    path('payment/',views.razorpayhome,name="razorpayhome"),
    path('paymenthandler/',views.paymenthandler,name="paymenthandler"),
    path('', views.user_home, name='user_home'),  


    #### New One #####
    path('add-product/', views.add_product, name='add_product'),
    
]

    




