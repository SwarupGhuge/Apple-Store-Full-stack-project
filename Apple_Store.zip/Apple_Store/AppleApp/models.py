from django.contrib.auth.models import User
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

# ----------------------------
# Product Model
# ----------------------------

class Product(models.Model):
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    price = models.IntegerField()
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    year = models.IntegerField(default=2024)
    storageGB = models.IntegerField(default=0)  # Default added
    modelName = models.CharField(max_length=255, default="Unknown Model")
    version = models.CharField(max_length=50, default="v1.0")
    color = models.CharField(max_length=50, default="Black")
    description = models.TextField()

    def __str__(self):
        return self.name

# ----------------------------
# UserProfile Model
# ----------------------------

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    is_admin = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} Profile"

# ----------------------------
# OTP Model
# ----------------------------

class OTP(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6)
    expires_at = models.DateTimeField()

    def __str__(self):
        return f"OTP for {self.user.username} - {self.otp}"

# ----------------------------
# Signal Handlers
# ----------------------------

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.get_or_create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        instance.profile.save()
    