import smtplib

with smtplib.SMTP('smtp.gmail.com', 587) as server:
    server.starttls()
    server.login('swarupghuge@gmail.com', 'jgkf gxbc iymw xfbv')  # Replace with your Gmail and App Password
    print("SMTP login successful")